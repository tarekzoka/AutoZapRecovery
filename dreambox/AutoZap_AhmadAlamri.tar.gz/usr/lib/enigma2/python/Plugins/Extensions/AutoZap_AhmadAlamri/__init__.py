# -*- coding: utf-8 -*-
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import os
from gettext import bindtextdomain, dgettext, gettext

PluginLanguageDomain = "AutoZapRecovery"
PluginLanguagePath = "Extensions/AutoZapRecovery/locale"


def localeInit():
    bindtextdomain(PluginLanguageDomain,
                   resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))


def _(txt):
    if dgettext(PluginLanguageDomain, txt):
        return dgettext(PluginLanguageDomain, txt)
    return gettext(txt)


localeInit()
language.addCallback(localeInit)
