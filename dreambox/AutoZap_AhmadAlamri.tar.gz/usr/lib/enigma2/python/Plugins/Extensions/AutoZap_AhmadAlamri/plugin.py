# -*- coding: utf-8 -*-
# =============================================================
# AutoZap Recovery v1.0 - DreamOS Edition
# Compatible with: DreamOS OE 2.5 / 2.6 (Python 2.7)
# Developer: Ahmad Alamri
# =============================================================

from __future__ import absolute_import

import os
import re
import socket
import time

_DEVELOPER_NAME = "Ahmad Alamri"
_LICENSE_STRING = "autozap recovery v1.0 - developed by: ahmad alamri"

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Label import Label
from Components.Language import language
from Components.config import (
    config, ConfigSubsection, ConfigEnableDisable,
    ConfigInteger, ConfigSelection, ConfigText, getConfigListEntry
)
from enigma import eTimer, getDesktop, iServiceInformation


# ================== التحقق من الترخيص ==================
def _verify_license():
    try:
        expected = "AutoZap Recovery v1.0 - Developed by: Ahmad Alamri".lower()
        if _DEVELOPER_NAME != "Ahmad Alamri" or expected != _LICENSE_STRING:
            return False
        return True
    except:
        return False


# ================== اكتشاف DreamOS ==================
def is_dreamos():
    try:
        for f in ["/etc/issue", "/etc/version", "/etc/os-release"]:
            if os.path.exists(f):
                try:
                    fh = open(f, "r")
                    content = fh.read().lower()
                    fh.close()
                    if ("dreamos" in content or
                        "dreambox" in content or
                        "opendreambox" in content):
                        return True
                except:
                    pass
        if os.path.exists("/lib/systemd/system/oscam.service"):
            return True
        if os.path.exists("/etc/systemd/system/oscam.service"):
            return True
    except:
        pass
    return False


DREAMOS_MODE = is_dreamos()


# ================== كلمات رياضية ==================
SPORTS_KEYWORDS = [
    "sport", "arena", "bein", "ssc", "espn", "canal+ sport", "dazn",
    "eurosport", "polsat sport", "nova sport", "match", "eleven",
    "football", "alkass", "premier", "ziggo", "sky sport", "spiler",
    "setanta", "super sport", "digi sport", "sportklub", "tnt sport",
    "la liga", "laliga", "champions", "bundesliga", "serie a", "motogp",
    "formula", "f1", "wwe", "fight", "nba", "live"
]


# ================== الترجمات ==================
STRINGS = {
    "ar": {
        "title": "AutoZap Recovery 1.0 - DreamOS Edition",
        "lang_option": "لغة البلجن / Language",
        "enabled": "تفعيل المراقبة والإنعاش التلقائي",
        "kill_code": "كود الإيقاف والتشغيل السريع بالريموت",
        "auto_sports": "التعرف الذكي على قنوات المباريات",
        "boost_system": "رفع أولوية معالجة الأوسكام والتيونر",
        "check_net": "فحص اتصال الإنترنت قبل التقليب",
        "cam_restart": "إعادة تشغيل الأوسكام تلقائياً عند الفشل",
        "lock_caid": "تثبيت أسرع شفرة ومنع التنقل العشوائي",
        "mode": "طريقة الإنعاش عند تجمد القناة",
        "mode_restart": "إعادة تشغيل القناة مكانها دون تقليب",
        "mode_zap": "تقليب مرئي لقناة مجاورة والعودة",
        "timeout": "مهلة انقطاع البث قبل التدخل (بالثواني)",
        "max_retries": "أقصى عدد محاولات قبل إعادة تشغيل الإيمو",
        "alert_type": "شكل تنبيه الإنعاش على الشاشة",
        "type_circle": "دائرة ممتلئة (نقطة)",
        "type_text": "إشعار كتابي (نص)",
        "type_silent": "الوضع الصامت (بدون تنبيه)",
        "circle_size": "حجم الدائرة الممتلئة (10 إلى 150)",
        "alert_pos": "مكان ظهور التنبيه على الشاشة",
        "pos_tr": "أعلى اليمين",
        "pos_tl": "أعلى اليسار",
        "pos_br": "أسفل اليمين",
        "pos_bl": "أسفل اليسار",
        "pos_cnt": "وسط الشاشة",
        "alert_size": "حجم التنبيه على الشاشة",
        "sz_sm": "صغير",
        "sz_md": "متوسط",
        "sz_lg": "كبير",
        "alert_color": "لون التنبيه",
        "col_gr": "أخضر",
        "col_gd": "أصفر ذهبي",
        "col_bl": "أزرق سماوي",
        "col_rd": "أحمر",
        "col_wh": "أبيض",
        "btn_cancel": "إلغاء",
        "btn_save": "حفظ",
        "btn_cam": "إنعاش الإيمو الآن",
        "status_active": "الحماية نشطة | القناة: %s | الإنعاش: %s",
        "status_disabled": "البلجن معطل حالياً",
        "cam_restarted": "تم إعادة تشغيل الأوسكام بنجاح!",
        "toast_on": "تم تشغيل AutoZap",
        "toast_off": "تم تعطيل AutoZap",
        "toast_net_err": "تنبيه: لا يوجد إنترنت",
        "toast_cam_ok": "تم إنعاش الأوسكام تلقائياً",
        "toast_zap": "إنعاش القناة: تقليب (%s/%s)",
        "toast_restart": "إنعاش القناة: إعادة تشغيل (%s/%s)",
        "channel_sports": "قناة رياضية",
        "channel_regular": "قناة عامة",
        "dreamos_detected": "تم اكتشاف DreamOS الرسمي ✓",
        "dreamos_not": "بيئة Enigma2 مفتوحة المصدر"
    },
    "en": {
        "title": "AutoZap Recovery 1.0 - DreamOS Edition",
        "lang_option": "Plugin Language / اللغة",
        "enabled": "Enable Auto Monitoring & Recovery",
        "kill_code": "Quick Remote Toggle Code",
        "auto_sports": "AI Auto-Detect Sports Channels",
        "boost_system": "Elevate Softcam & Tuner Priority",
        "check_net": "Verify Internet Before Zap",
        "cam_restart": "Auto Restart Softcam on Failure",
        "lock_caid": "Lock Fastest ECM & Prevent CAID Hopping",
        "mode": "Recovery Method on Freeze",
        "mode_restart": "Restart channel in place",
        "mode_zap": "Zap to adjacent and return",
        "timeout": "ECM Loss Timeout (seconds)",
        "max_retries": "Max Retries Before Softcam Restart",
        "alert_type": "On-Screen Alert Style",
        "type_circle": "Filled Circle (Dot)",
        "type_text": "Text Banner",
        "type_silent": "Silent Mode",
        "circle_size": "Circle Size (10 to 150)",
        "alert_pos": "Notification Position",
        "pos_tr": "Top Right",
        "pos_tl": "Top Left",
        "pos_br": "Bottom Right",
        "pos_bl": "Bottom Left",
        "pos_cnt": "Center",
        "alert_size": "Banner Size",
        "sz_sm": "Small",
        "sz_md": "Medium",
        "sz_lg": "Large",
        "alert_color": "Notification Color",
        "col_gr": "Green",
        "col_gd": "Golden Yellow",
        "col_bl": "Sky Blue",
        "col_rd": "Red",
        "col_wh": "White",
        "btn_cancel": "Cancel",
        "btn_save": "Save",
        "btn_cam": "Restart Cam Now",
        "status_active": "Guard Active | Channel: %s | Rescues: %s",
        "status_disabled": "Plugin Disabled",
        "cam_restarted": "Softcam restarted successfully!",
        "toast_on": "AutoZap Activated",
        "toast_off": "AutoZap Disabled",
        "toast_net_err": "Alert: No Internet",
        "toast_cam_ok": "Softcam restarted automatically",
        "toast_zap": "Recovery: Zap (%s/%s)",
        "toast_restart": "Recovery: Restart (%s/%s)",
        "channel_sports": "Sports Channel",
        "channel_regular": "Standard Channel",
        "dreamos_detected": "DreamOS Detected ✓",
        "dreamos_not": "Open Enigma2 Environment"
    }
}


# ================== الكونفيج ==================
config.plugins.autozap_alamri = ConfigSubsection()
config.plugins.autozap_alamri.lang = ConfigSelection(default="auto", choices=[
    ("auto", "تلقائي (System Default)"),
    ("ar", "العربية"),
    ("en", "English")
])
config.plugins.autozap_alamri.enabled = ConfigEnableDisable(default=True)
config.plugins.autozap_alamri.kill_code = ConfigText(default="00", fixed_size=False)
config.plugins.autozap_alamri.auto_sports = ConfigEnableDisable(default=True)
config.plugins.autozap_alamri.boost_system = ConfigEnableDisable(default=True)
config.plugins.autozap_alamri.check_net = ConfigEnableDisable(default=True)
config.plugins.autozap_alamri.cam_restart = ConfigEnableDisable(default=True)
config.plugins.autozap_alamri.lock_caid = ConfigEnableDisable(default=True)
config.plugins.autozap_alamri.mode = ConfigSelection(default="restart", choices=[
    ("restart", "restart"),
    ("zap", "zap")
])
config.plugins.autozap_alamri.timeout = ConfigInteger(default=15, limits=(5, 500))
config.plugins.autozap_alamri.max_retries = ConfigInteger(default=10, limits=(1, 500))
config.plugins.autozap_alamri.alert_type = ConfigSelection(default="circle", choices=[
    ("circle", "circle"),
    ("text", "text"),
    ("silent", "silent")
])
config.plugins.autozap_alamri.circle_size = ConfigInteger(default=40, limits=(10, 150))
config.plugins.autozap_alamri.alert_pos = ConfigSelection(default="top_right", choices=[
    ("top_right", "top_right"),
    ("top_left", "top_left"),
    ("bottom_right", "bottom_right"),
    ("bottom_left", "bottom_left"),
    ("center", "center")
])
config.plugins.autozap_alamri.alert_size = ConfigSelection(default="large", choices=[
    ("small", "small"),
    ("medium", "medium"),
    ("large", "large")
])
config.plugins.autozap_alamri.alert_color = ConfigSelection(default="#00ff00", choices=[
    ("#00ff00", "green"),
    ("#f0a500", "gold"),
    ("#00bfff", "blue"),
    ("#ff3333", "red"),
    ("#ffffff", "white")
])


def get_current_lang():
    opt = config.plugins.autozap_alamri.lang.value
    if opt in ("ar", "en"):
        return opt
    try:
        sys_l = language.getLanguage()[:2].lower()
        return "ar" if sys_l == "ar" else "en"
    except:
        return "ar"


def _T(key):
    l = get_current_lang()
    return STRINGS.get(l, STRINGS["ar"]).get(key, key)


# ================== نافذة التنبيه ==================
class AutoZapToast(Screen):
    def __init__(self, session, msg, color="#00ff00", pos="top_right",
                 is_circle=False, circle_sz=40, size_choice="large"):
        try:
            desk = getDesktop(0).size()
            dw, dh = desk.width(), desk.height()
        except:
            dw, dh = 1920, 1080

        margin_x, margin_y = 50, 60

        if is_circle:
            cs = int(circle_sz)
            w, h = cs + 20, cs + 20
            font_sz = cs
            display_text = "●"
            bg_color = "transparent"
        else:
            sz = str(size_choice)
            if sz == "small":
                w, h, font_sz = 360, 55, 24
            elif sz == "large":
                w, h, font_sz = 700, 100, 42
            else:
                w, h, font_sz = 520, 75, 32
            display_text = msg
            bg_color = "#b0000000"

        if pos == "top_right":
            x, y = dw - w - margin_x, margin_y
        elif pos == "top_left":
            x, y = margin_x, margin_y
        elif pos == "bottom_right":
            x, y = dw - w - margin_x, dh - h - margin_y
        elif pos == "bottom_left":
            x, y = margin_x, dh - h - margin_y
        else:
            x, y = (dw - w) // 2, (dh - h) // 2

        self.skin = """
        <screen name="AutoZapToast" position="%d,%d" size="%d,%d"
                zPosition="150" backgroundColor="%s" flags="wfNoBorder">
            <widget name="msg" position="0,0" size="%d,%d"
                    font="Regular;%d" halign="center" valign="center"
                    foregroundColor="%s" backgroundColor="%s"
                    transparent="1" />
        </screen>""" % (x, y, w, h, bg_color, w, h, font_sz, color, bg_color)

        Screen.__init__(self, session)
        self.session = session
        self["msg"] = Label(display_text)
        self.timer = eTimer()
        try:
            self.timer.timeout.connect(self.close)
        except:
            try:
                self.timer.callback.append(self.close)
            except:
                pass
        self.onLayoutFinish.append(self.start_timer)

    def start_timer(self):
        try:
            self.timer.start(2500, True)
        except:
            pass


# ================== النواة ==================
class AutoZapCore:
    def __init__(self, session):
        self.session = session
        self.timer = eTimer()
        try:
            self.timer.timeout.connect(self.monitor)
        except:
            try:
                self.timer.callback.append(self.monitor)
            except:
                pass

        self.return_timer = eTimer()
        try:
            self.return_timer.timeout.connect(self.finish_recovery)
        except:
            try:
                self.return_timer.callback.append(self.finish_recovery)
            except:
                pass

        self.last_ref = None
        self.target_ref = None
        self.recovery_action = None
        self.recovering = False
        self.channel_tune_time = 0
        self.cooldown_until = 0
        self.last_boost_time = 0
        self.recovery_count = 0
        self.locked_srvid = set()
        self.key_buffer = ""
        self.last_key_time = 0
        self.retries = 0
        self.error_streak = 0
        self.is_current_sports = False
        self.valid = _verify_license()
        self.start()

    def start(self):
        if not self.valid:
            return
        if not config.plugins.autozap_alamri.enabled.value:
            try:
                self.timer.stop()
            except:
                pass
            return
        self.apply_hardware_boost()
        try:
            self.timer.start(2000)
        except:
            pass

    def check_sports_identity(self):
        try:
            service = self.session.nav.getCurrentService()
            if not service:
                return False
            info = service.info()
            if not info:
                return False

            ch_name = info.getName().lower()
            for kw in SPORTS_KEYWORDS:
                if kw in ch_name:
                    return True

            event = info.getEvent(0)
            if event:
                ev_name = event.getEventName().lower()
                for kw in SPORTS_KEYWORDS:
                    if kw in ev_name:
                        return True
        except:
            pass
        return False

    def handle_key(self, digit):
        kill_code = str(config.plugins.autozap_alamri.kill_code.value).strip()
        if not kill_code:
            return
        now = time.time()
        if (now - self.last_key_time) > 3.0:
            self.key_buffer = ""
        self.last_key_time = now
        self.key_buffer += digit

        if len(self.key_buffer) > len(kill_code):
            self.key_buffer = self.key_buffer[-len(kill_code):]

        if self.key_buffer == kill_code:
            self.key_buffer = ""
            self.toggle_kill_switch()

    def toggle_kill_switch(self):
        cur = config.plugins.autozap_alamri.enabled.value
        new_val = not cur
        config.plugins.autozap_alamri.enabled.value = new_val
        config.plugins.autozap_alamri.enabled.save()
        config.plugins.autozap_alamri.save()
        self.recovering = False

        if new_val:
            msg = _T("toast_on")
            col = "#00ff00"
            self.start()
        else:
            msg = _T("toast_off")
            col = "#ff3333"
            try:
                self.timer.stop()
            except:
                pass

        try:
            self.session.open(AutoZapToast, msg, col, "center", False, 40, "large")
        except:
            pass

    def apply_hardware_boost(self):
        if not config.plugins.autozap_alamri.boost_system.value:
            return
        try:
            os.system("renice -n -19 $(pidof oscam ncam 2>/dev/null) "
                      ">/dev/null 2>&1 &")

            if os.path.exists("/usr/bin/ionice") or os.path.exists("/bin/ionice"):
                os.system("ionice -c 1 -n 0 -p $(pidof oscam ncam 2>/dev/null) "
                          ">/dev/null 2>&1 &")

            if os.path.exists("/sbin/sysctl") or os.path.exists("/usr/sbin/sysctl"):
                os.system("sysctl -w net.core.rmem_max=8388608 >/dev/null 2>&1 &")
                os.system("sysctl -w net.core.wmem_max=8388608 >/dev/null 2>&1 &")
        except:
            pass

    def check_network(self):
        if not config.plugins.autozap_alamri.check_net.value:
            return True
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.6)
            s.connect(("1.1.1.1", 53))
            s.close()
            return True
        except:
            return False

    def restart_softcam(self):
        try:
            if DREAMOS_MODE:
                services = []
                for svc in ["oscam", "ncam", "oscam-emu", "oscam-trunk"]:
                    if (os.path.exists("/lib/systemd/system/%s.service" % svc) or
                        os.path.exists("/etc/systemd/system/%s.service" % svc)):
                        services.append(svc)

                if services:
                    for svc in services:
                        os.system("systemctl restart %s >/dev/null 2>&1 &" % svc)
                    self.trigger_alert(_T("toast_cam_ok"))
                    return

                os.system("killall -9 oscam ncam 2>/dev/null; sleep 1; "
                          "for bin in /usr/bin/oscam* /usr/bin/ncam* "
                          "/usr/sbin/oscam* /usr/sbin/ncam*; do "
                          "[ -x \"$bin\" ] && \"$bin\" -b & break; done &")
            else:
                os.system("killall -9 oscam ncam 2>/dev/null; sleep 1; "
                          "for bin in /usr/bin/oscam* /usr/bin/ncam*; do "
                          "[ -x \"$bin\" ] && \"$bin\" -b & break; done &")

            self.trigger_alert(_T("toast_cam_ok"))
        except:
            pass

    def trigger_alert(self, msg_text, force_color=None):
        atype = config.plugins.autozap_alamri.alert_type.value
        if atype == "silent":
            return

        is_circ = (atype == "circle")
        circ_sz = config.plugins.autozap_alamri.circle_size.value
        color = force_color if force_color else config.plugins.autozap_alamri.alert_color.value
        pos = config.plugins.autozap_alamri.alert_pos.value
        sz = config.plugins.autozap_alamri.alert_size.value

        try:
            from Tools.Notifications import AddNotification
            AddNotification(AutoZapToast, msg_text, color, pos, is_circ, circ_sz, sz)
        except:
            try:
                self.session.open(AutoZapToast, msg_text, color, pos, is_circ, circ_sz, sz)
            except:
                pass

    def get_dvbapi_files(self):
        found = []
        dirs = [
            "/etc/oscam",
            "/etc/ncam",
            "/etc/tuxbox/config/oscam",
            "/etc/tuxbox/config/ncam",
            "/etc/tuxbox/config/oscam-emu",
            "/etc/tuxbox/config/oscam-trunk",
            "/etc/tuxbox/config",
            "/var/tuxbox/config",
            "/usr/keys",
            "/etc/enigma2/oscam"
        ]
        for d in dirs:
            for name in ["oscam.dvbapi", "ncam.dvbapi", "dvbapi"]:
                p = os.path.join(d, name)
                if os.path.exists(p) and p not in found:
                    found.append(p)
        return found

    def lock_best_caid(self, ecm_path):
        if not config.plugins.autozap_alamri.lock_caid.value:
            return
        try:
            fh = open(ecm_path, "r")
            content = fh.read().lower()
            fh.close()

            if "timeout" in content or "not found" in content or "cannot decode" in content:
                return

            caid_m = re.search(r'caid:\s*0x([0-9a-f]+)', content)
            prov_m = re.search(r'prov:\s*0x([0-9a-f]+)', content)
            srv_m = re.search(r'srvid:\s*0x([0-9a-f]+)', content)

            if caid_m and srv_m:
                caid = caid_m.group(1).zfill(4)
                srvid = srv_m.group(1).zfill(4)
                prov = prov_m.group(1).zfill(6) if prov_m else "000000"

                if srvid in self.locked_srvid:
                    return

                rule = "P: %s:%s:%s 1" % (caid, prov, srvid)
                target_files = self.get_dvbapi_files()

                for dvbapi in target_files:
                    existing = []
                    if os.path.exists(dvbapi):
                        fi = open(dvbapi, "r")
                        existing = [l.strip() for l in fi.readlines() if l.strip()]
                        fi.close()

                    cleaned = [l for l in existing
                               if not l.startswith("P: %s:" % caid) and srvid not in l]
                    new_content = [rule] + cleaned
                    fo = open(dvbapi, "w")
                    fo.write("\n".join(new_content) + "\n")
                    fo.close()

                self.locked_srvid.add(srvid)
        except:
            pass

    def is_channel_crypted(self):
        try:
            service = self.session.nav.getCurrentService()
            if service:
                info = service.info()
                if info:
                    c1 = (info.getInfo(iServiceInformation.sIsCrypted) == 1)
                    try:
                        c2 = bool(info.getInfoFlag(iServiceInformation.sIsCrypted))
                    except:
                        c2 = False
                    return c1 or c2
        except:
            pass
        return False

    def finish_recovery(self):
        try:
            if self.recovery_action == "zap":
                from Screens.InfoBar import InfoBar
                if InfoBar.instance and hasattr(InfoBar.instance, "zapUp"):
                    InfoBar.instance.zapUp()
                elif self.target_ref:
                    self.session.nav.playService(self.target_ref)
            elif self.recovery_action == "restart":
                if self.target_ref:
                    self.session.nav.playService(self.target_ref)
        except:
            pass

        self.recovering = False
        self.target_ref = None
        self.recovery_action = None
        self.error_streak = 0
        self.channel_tune_time = time.time()

    def is_ecm_error(self, data):
        for t in ["timeout", "not found", "cannot decode",
                  "no matching reader", "dropped", "network error"]:
            if t in data:
                return True
        return False

    def is_ecm_valid(self, data):
        for v in ["found", "cache", "cw0:", "cw1:", "ecm time"]:
            if v in data:
                return True
        return False

    def monitor(self):
        if not self.valid or not config.plugins.autozap_alamri.enabled.value:
            return

        if self.recovering:
            return

        try:
            from Screens.Standby import inStandby
            if inStandby:
                self.retries = 0
                return
        except:
            pass

        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not ref:
                self.retries = 0
                return

            ref_str = ref.toString()
            now = time.time()

            if ref_str != self.last_ref:
                self.last_ref = ref_str
                self.retries = 0
                self.error_streak = 0
                self.cooldown_until = now + 5
                self.channel_tune_time = now
                self.is_current_sports = self.check_sports_identity()
                self.apply_hardware_boost()
                return

            if now < self.cooldown_until:
                return

            ecm_path = "/tmp/ecm.info"
            ecm_exists = os.path.exists(ecm_path)
            is_crypted = self.is_channel_crypted()

            if not is_crypted and not ecm_exists:
                return

            if ecm_exists:
                self.lock_best_caid(ecm_path)

            is_frozen = False
            auto_sp = (config.plugins.autozap_alamri.auto_sports.value and
                       self.is_current_sports)

            if not ecm_exists:
                initial_grace = 8 if auto_sp else 12
                if (now - self.channel_tune_time) > initial_grace:
                    is_frozen = True
            else:
                mtime = os.path.getmtime(ecm_path)
                try:
                    fh = open(ecm_path, "r")
                    data = fh.read().lower()
                    fh.close()
                except:
                    data = ""

                if self.is_ecm_error(data):
                    self.error_streak += 1
                    req_streak = 2 if auto_sp else 3
                    if self.error_streak >= req_streak:
                        is_frozen = True
                elif self.is_ecm_valid(data):
                    self.error_streak = 0
                    max_safe_limit = 20 if auto_sp else 26
                    if (now - mtime) > max_safe_limit:
                        is_frozen = True
                else:
                    if (now - mtime) > 20:
                        is_frozen = True

            if is_frozen:
                if not self.check_network():
                    self.trigger_alert(_T("toast_net_err"), force_color="#ff3333")
                    self.cooldown_until = now + 10
                    return

                max_r = int(config.plugins.autozap_alamri.max_retries.value)
                if self.retries < max_r:
                    self.retries += 1
                    self.recovery_count += 1
                    self.cooldown_until = now + 8
                    self.recovering = True
                    self.target_ref = ref

                    mode = config.plugins.autozap_alamri.mode.value
                    if mode == "zap":
                        self.recovery_action = "zap"
                        zapped = False
                        try:
                            from Screens.InfoBar import InfoBar
                            if InfoBar.instance and hasattr(InfoBar.instance, "zapDown"):
                                InfoBar.instance.zapDown()
                                zapped = True
                        except:
                            zapped = False

                        if zapped:
                            msg = _T("toast_zap") % (self.retries, max_r)
                            self.trigger_alert(msg)
                            self.return_timer.start(2500, True)
                        else:
                            self.recovery_action = "restart"
                            self.session.nav.stopService()
                            self.session.nav.playService(ref)
                            self.recovering = False
                            self.channel_tune_time = now
                    else:
                        self.recovery_action = "restart"
                        msg = _T("toast_restart") % (self.retries, max_r)
                        self.trigger_alert(msg)
                        self.session.nav.stopService()
                        self.session.nav.playService(ref)
                        self.recovering = False
                        self.channel_tune_time = now
                else:
                    if config.plugins.autozap_alamri.cam_restart.value:
                        self.retries = 0
                        self.cooldown_until = now + 10
                        self.restart_softcam()
            else:
                if ecm_exists and (now - os.path.getmtime(ecm_path)) < 5:
                    self.retries = 0
                    self.error_streak = 0
        except:
            pass


core_instance = None


# ================== ربط مفاتيح الريموت ==================
def hook_infobar_keys():
    try:
        from Screens.InfoBarGenerics import InfoBarNumberZap
        if hasattr(InfoBarNumberZap, "keyNumberGlobal"):
            orig_num = InfoBarNumberZap.keyNumberGlobal

            def zap_num(self, number):
                try:
                    if core_instance:
                        core_instance.handle_key(str(number))
                except:
                    pass
                return orig_num(self, number)

            InfoBarNumberZap.keyNumberGlobal = zap_num
    except:
        pass

    try:
        from Screens.InfoBar import InfoBar
        if hasattr(InfoBar, "keyZero"):
            orig_zero = InfoBar.keyZero

            def zap_zero(self):
                try:
                    if core_instance:
                        core_instance.handle_key("0")
                except:
                    pass
                return orig_zero(self)

            InfoBar.keyZero = zap_zero
    except:
        pass


def sessionstart(reason, session=None, **kwargs):
    global core_instance
    s = session if session is not None else kwargs.get("session")
    if s is not None and reason == 0:
        try:
            core_instance = AutoZapCore(s)
            hook_infobar_keys()
        except:
            pass


# ================== شاشة الإعدادات (سكين مدمج) ==================
class AutoZapSetup(ConfigListScreen, Screen):
    skin = """
    <screen name="AutoZapSetup" position="center,center" size="840,660"
            title="AutoZap Recovery 1.0 - DreamOS">

        <widget name="config" position="20,20" size="800,440"
                scrollbarMode="showOnDemand"
                font="Regular;21" itemHeight="38" />

        <widget source="status_info" render="Label"
                position="20,475" size="800,30"
                font="Regular;19" halign="center" valign="center"
                foregroundColor="#00ff00" transparent="1" />

        <widget source="env_info" render="Label"
                position="20,510" size="800,25"
                font="Regular;17" halign="center" valign="center"
                foregroundColor="#00bfff" transparent="1" />

        <widget source="author_info" render="Label"
                position="20,540" size="800,25"
                font="Regular;17" halign="center" valign="center"
                foregroundColor="#f0a500" transparent="1" />

        <widget source="key_red" render="Label"
                position="90,585" size="170,45" zPosition="1"
                font="Regular;20" halign="center" valign="center"
                backgroundColor="#9f1313" transparent="0" />

        <widget source="key_green" render="Label"
                position="335,585" size="170,45" zPosition="1"
                font="Regular;20" halign="center" valign="center"
                backgroundColor="#0b7e13" transparent="0" />

        <widget source="key_yellow" render="Label"
                position="580,585" size="170,45" zPosition="1"
                font="Regular;19" halign="center" valign="center"
                backgroundColor="#a08000" transparent="0" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.list = []
        ConfigListScreen.__init__(self, self.list)

        self["status_info"] = StaticText("")
        self["env_info"] = StaticText("")
        self["author_info"] = StaticText(
            "AutoZap Recovery v1.0 - Developed by: Ahmad Alamri")
        self["key_red"] = StaticText("")
        self["key_green"] = StaticText("")
        self["key_yellow"] = StaticText("")

        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {
                "green": self.save,
                "red": self.cancel,
                "yellow": self.manual_cam_restart,
                "cancel": self.cancel,
                "ok": self.save
            }, -2)

        self.create_setup()

    def create_setup(self):
        self.setTitle(_T("title"))
        self["key_red"].setText(_T("btn_cancel"))
        self["key_green"].setText(_T("btn_save"))
        self["key_yellow"].setText(_T("btn_cam"))

        config.plugins.autozap_alamri.mode.setChoices([
            ("restart", _T("mode_restart")),
            ("zap", _T("mode_zap"))
        ])
        config.plugins.autozap_alamri.alert_type.setChoices([
            ("circle", _T("type_circle")),
            ("text", _T("type_text")),
            ("silent", _T("type_silent"))
        ])
        config.plugins.autozap_alamri.alert_pos.setChoices([
            ("top_right", _T("pos_tr")),
            ("top_left", _T("pos_tl")),
            ("bottom_right", _T("pos_br")),
            ("bottom_left", _T("pos_bl")),
            ("center", _T("pos_cnt"))
        ])
        config.plugins.autozap_alamri.alert_size.setChoices([
            ("small", _T("sz_sm")),
            ("medium", _T("sz_md")),
            ("large", _T("sz_lg"))
        ])
        config.plugins.autozap_alamri.alert_color.setChoices([
            ("#00ff00", _T("col_gr")),
            ("#f0a500", _T("col_gd")),
            ("#00bfff", _T("col_bl")),
            ("#ff3333", _T("col_rd")),
            ("#ffffff", _T("col_wh"))
        ])

        self.list = [
            getConfigListEntry(_T("enabled"), config.plugins.autozap_alamri.enabled),
            getConfigListEntry(_T("lang_option"), config.plugins.autozap_alamri.lang)
        ]

        if config.plugins.autozap_alamri.enabled.value:
            ch_type = (_T("channel_sports")
                       if (core_instance and core_instance.is_current_sports)
                       else _T("channel_regular"))
            rescues = core_instance.recovery_count if core_instance else 0
            self["status_info"].setText(_T("status_active") % (ch_type, rescues))

            self.list.append(getConfigListEntry(_T("kill_code"),
                             config.plugins.autozap_alamri.kill_code))
            self.list.append(getConfigListEntry(_T("auto_sports"),
                             config.plugins.autozap_alamri.auto_sports))
            self.list.append(getConfigListEntry(_T("boost_system"),
                             config.plugins.autozap_alamri.boost_system))
            self.list.append(getConfigListEntry(_T("check_net"),
                             config.plugins.autozap_alamri.check_net))
            self.list.append(getConfigListEntry(_T("cam_restart"),
                             config.plugins.autozap_alamri.cam_restart))
            self.list.append(getConfigListEntry(_T("lock_caid"),
                             config.plugins.autozap_alamri.lock_caid))
            self.list.append(getConfigListEntry(_T("mode"),
                             config.plugins.autozap_alamri.mode))
            self.list.append(getConfigListEntry(_T("timeout"),
                             config.plugins.autozap_alamri.timeout))
            self.list.append(getConfigListEntry(_T("max_retries"),
                             config.plugins.autozap_alamri.max_retries))
            self.list.append(getConfigListEntry(_T("alert_type"),
                             config.plugins.autozap_alamri.alert_type))

            atype = config.plugins.autozap_alamri.alert_type.value
            if atype == "text":
                self.list.append(getConfigListEntry(_T("alert_pos"),
                                 config.plugins.autozap_alamri.alert_pos))
                self.list.append(getConfigListEntry(_T("alert_size"),
                                 config.plugins.autozap_alamri.alert_size))
                self.list.append(getConfigListEntry(_T("alert_color"),
                                 config.plugins.autozap_alamri.alert_color))
            elif atype == "circle":
                self.list.append(getConfigListEntry(_T("alert_pos"),
                                 config.plugins.autozap_alamri.alert_pos))
                self.list.append(getConfigListEntry(_T("circle_size"),
                                 config.plugins.autozap_alamri.circle_size))
                self.list.append(getConfigListEntry(_T("alert_color"),
                                 config.plugins.autozap_alamri.alert_color))
        else:
            self["status_info"].setText(_T("status_disabled"))

        if DREAMOS_MODE:
            self["env_info"].setText(_T("dreamos_detected"))
        else:
            self["env_info"].setText(_T("dreamos_not"))

        self["config"].list = self.list
        self["config"].setList(self.list)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.create_setup()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.create_setup()

    def manual_cam_restart(self):
        global core_instance
        if core_instance:
            core_instance.restart_softcam()
            self["status_info"].setText(_T("cam_restarted"))

    def save(self):
        for x in self["config"].list:
            x[1].save()
        config.plugins.autozap_alamri.save()
        global core_instance
        if core_instance:
            core_instance.apply_hardware_boost()
            core_instance.start()
        self.close()

    def cancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()


def main(session, **kwargs):
    session.open(AutoZapSetup)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=sessionstart
        ),
        PluginDescriptor(
            name="AutoZap Recovery 1.0 (DreamOS)",
            description="AutoZap Recovery | Developer: Ahmad Alamri",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=None,
            fnc=main
        )
    ]
